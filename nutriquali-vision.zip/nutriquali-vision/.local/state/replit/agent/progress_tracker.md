[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Verify the project is working using the feedback tool
[x] 4. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool
[x] 5. Atualizar layout da página de Login com a nova logo
[x] 6. Atualizar layout da Home para ser idêntico à imagem anexada
[x] 7. Atualizar layout do Perfil para ser idêntico à imagem anexada
[x] 8. Atualizar layout de Descongelamento para ser idêntico à imagem anexada
[x] 9. Garantir que todas as outras páginas sigam o novo padrão visual