import { DemoController } from '@/components/demo/DemoController';

const Index = () => {
  return <DemoController />;
};

export default Index;
