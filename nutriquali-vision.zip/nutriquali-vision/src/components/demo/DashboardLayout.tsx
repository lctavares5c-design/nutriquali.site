import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { 
  Home, 
  Thermometer, 
  AlertTriangle, 
  User,
  LogOut,
  Settings,
  Bell,
  Search,
  UtensilsCrossed,
  Sandwich,
  ChefHat,
  Snowflake,
  Wind,
  ThermometerSnowflake,
  ArrowRightLeft,
  Sparkles
} from 'lucide-react';
import logoNutriQuali from '@/assets/logo-nutriquali.png';

interface DashboardLayoutProps {
  children: ReactNode;
  activeTab: 'home' | 'descongelamento' | 'nao-conformidades' | 'perfil';
}

const menuItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'cardapio', label: 'Cardápio', icon: UtensilsCrossed },
  { id: 'lanche', label: 'Lanche', icon: Sandwich },
  { id: 'coccao', label: 'Cocção e Distribuição', icon: ChefHat },
  { id: 'descongelamento', label: 'Descongelamento', icon: Thermometer },
  { id: 'camaras-frias', label: 'Câmaras Frias', icon: Snowflake },
  { id: 'refrigeracao', label: 'Refrigeração', icon: ThermometerSnowflake },
  { id: 'resfriamento', label: 'Resfriamento', icon: Wind },
  { id: 'pass-through-equip', label: 'Pass Through - Equip.', icon: ArrowRightLeft },
  { id: 'pass-through-alim', label: 'Pass Through - Alim.', icon: ArrowRightLeft },
  { id: 'higienizacao-camaras', label: 'Higienização - Câmaras', icon: Sparkles },
  { id: 'higienizacao-equip', label: 'Higienização - Equip.', icon: Sparkles },
  { id: 'higienizacao-grande', label: 'Higienização - Grande', icon: Sparkles },
  { id: 'higienizacao-pequeno', label: 'Higienização - Pequeno', icon: Sparkles },
  { id: 'higienizacao-instal', label: 'Higienização - Instal.', icon: Sparkles },
  { id: 'nao-conformidades', label: 'Não Conformidades', icon: AlertTriangle },
];

const bottomItems = [
  { id: 'configuracoes', label: 'Configurações', icon: Settings },
  { id: 'perfil', label: 'Perfil', icon: User },
  { id: 'sair', label: 'Sair', icon: LogOut },
];

export const DashboardLayout = ({ children, activeTab }: DashboardLayoutProps) => {
  return (
    <div className="min-h-screen flex bg-[#f5f7fa]">
      {/* Sidebar */}
      <motion.aside 
        className="w-52 bg-[#1e3a5f] text-white flex flex-col fixed h-full z-20"
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="p-4 border-b border-white/10">
          <img src={logoNutriQuali} alt="NutriQuali IA" className="h-9 brightness-0 invert" />
        </div>
        <div className="px-4 py-2">
          <span className="text-[10px] uppercase tracking-wider text-white/50 font-medium">Menu</span>
        </div>
        <nav className="flex-1 px-2 overflow-y-auto">
          {menuItems.map((item, idx) => {
            const isActive = activeTab === item.id;
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 + idx * 0.02 }}
              >
                <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[13px] transition-all cursor-pointer mb-0.5 ${
                  isActive ? 'bg-primary text-white' : 'text-white/70 hover:bg-white/10'
                }`}>
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{item.label}</span>
                </div>
              </motion.div>
            );
          })}
        </nav>
        <div className="p-2 border-t border-white/10 mt-auto">
          {bottomItems.map((item) => (
            <div key={item.id} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[13px] text-white/70 hover:bg-white/10 cursor-pointer ${
              activeTab === item.id ? 'bg-white/10 text-white' : ''
            }`}>
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </motion.aside>

      <div className="flex-1 flex flex-col ml-52">
        <motion.header 
          className="h-14 bg-white border-b border-border flex items-center justify-between px-5 sticky top-0 z-10"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 bg-[#f5f7fa] rounded-lg px-3 py-2 w-72">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input type="text" placeholder="Buscar por unidade ou código..." className="bg-transparent text-sm outline-none w-full" />
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg hover:bg-muted">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <span className="absolute top-0.5 right-0.5 w-4 h-4 bg-destructive rounded-full text-[10px] text-white flex items-center justify-center font-medium">3</span>
            </button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-sm">M</div>
              <div className="text-right">
                <p className="text-sm font-semibold text-foreground">Maria Silva</p>
                <p className="text-xs text-muted-foreground">Nutricionista Qualidade</p>
              </div>
            </div>
          </div>
        </motion.header>
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  );
};
