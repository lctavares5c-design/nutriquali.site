import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Shield, 
  Mail, 
  Building2,
  ChefHat,
  ClipboardCheck,
  Check
} from 'lucide-react';
import { DashboardLayout } from './DashboardLayout';

interface PerfilSectionProps {
  onComplete: () => void;
}

export const PerfilSection = ({ onComplete }: PerfilSectionProps) => {
  const [currentRole, setCurrentRole] = useState('qualidade');
  const [isChanging, setIsChanging] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const roles = [
    { id: 'qualidade', label: 'Coordenador de Qualidade', icon: ClipboardCheck, color: 'bg-primary' },
    { id: 'comissario', label: 'Comissário', icon: ChefHat, color: 'bg-warning' },
  ];

  useEffect(() => {
    // Animate role change
    const sequence = async () => {
      await new Promise(r => setTimeout(r, 2000));
      setIsChanging(true);
      
      await new Promise(r => setTimeout(r, 1000));
      setCurrentRole('comissario');
      setIsChanging(false);
      setShowConfirmation(true);
      
      await new Promise(r => setTimeout(r, 2000));
      onComplete();
    };

    sequence();
  }, [onComplete]);

  const currentRoleData = roles.find(r => r.id === currentRole);

  return (
    <DashboardLayout activeTab="perfil">
      <div className="p-6 space-y-6 max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">
            Perfil do Usuário
          </h1>
          <p className="text-muted-foreground">
            Gerencie suas informações e permissões de acesso
          </p>
        </motion.div>

        {/* Profile Card */}
        <motion.div 
          className="glass-card rounded-2xl p-8"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          {/* Avatar */}
          <div className="flex flex-col items-center mb-8">
            <motion.div 
              className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold mb-4 shadow-glow"
              animate={isChanging ? { rotate: [0, 360] } : {}}
              transition={{ duration: 0.5 }}
            >
              M
            </motion.div>
            <h2 className="text-2xl font-display font-bold text-foreground">Maria Silva</h2>
            <p className="text-muted-foreground">maria.qualidade@empresa</p>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-xl">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">E-mail</p>
                <p className="font-medium text-foreground">maria.qualidade@empresa</p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-xl">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Empresa</p>
                <p className="font-medium text-foreground">PetroFood Corp.</p>
              </div>
            </div>
          </div>

          {/* Role Section */}
          <div className="border-t border-border pt-8">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-foreground">Função de Acesso</h3>
            </div>

            <div className="flex gap-4">
              {roles.map((role) => (
                <motion.div
                  key={role.id}
                  className={`flex-1 relative cursor-pointer`}
                  animate={isChanging && role.id === 'comissario' ? { scale: [1, 1.05, 1] } : {}}
                  transition={{ duration: 0.5 }}
                >
                  <div 
                    className={`p-6 rounded-xl border-2 transition-all ${
                      currentRole === role.id
                        ? 'border-primary bg-primary/5 shadow-glow'
                        : 'border-border hover:border-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl ${role.color} flex items-center justify-center text-white`}>
                        <role.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{role.label}</p>
                        <p className="text-sm text-muted-foreground">
                          {role.id === 'qualidade' ? 'Acesso completo' : 'Acesso operacional'}
                        </p>
                      </div>
                    </div>

                    {currentRole === role.id && (
                      <motion.div
                        className="absolute top-3 right-3 w-6 h-6 bg-primary rounded-full flex items-center justify-center"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', stiffness: 300 }}
                      >
                        <Check className="w-4 h-4 text-white" />
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Confirmation Toast */}
          <AnimatePresence>
            {showConfirmation && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.95 }}
                className="mt-6 p-4 bg-success/10 border border-success/30 rounded-xl flex items-center gap-3"
              >
                <div className="w-10 h-10 bg-success rounded-full flex items-center justify-center">
                  <Check className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-success">Função alterada com sucesso!</p>
                  <p className="text-sm text-muted-foreground">
                    Agora você está acessando como <span className="font-medium">{currentRoleData?.label}</span>
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </DashboardLayout>
  );
};
