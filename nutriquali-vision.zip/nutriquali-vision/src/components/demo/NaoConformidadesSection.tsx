import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Eye,
  Check,
  X,
  FileText
} from 'lucide-react';
import { DashboardLayout } from './DashboardLayout';

interface NaoConformidadesSectionProps {
  onComplete: () => void;
}

type TabType = 'pendentes' | 'validadas' | 'descartadas';

const HighlightBox = ({ children, active, pulse = false }: { children: React.ReactNode; active: boolean; pulse?: boolean }) => (
  <div className="relative">
    <AnimatePresence>
      {active && (
        <motion.div
          className="absolute -inset-2 bg-primary/20 rounded-xl border-2 border-primary z-0"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            boxShadow: pulse ? ['0 0 0 0 rgba(45, 212, 191, 0)', '0 0 20px 10px rgba(45, 212, 191, 0.3)', '0 0 0 0 rgba(45, 212, 191, 0)'] : 'none'
          }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3, boxShadow: { duration: 2, repeat: Infinity } }}
        />
      )}
    </AnimatePresence>
    <div className="relative z-10">{children}</div>
  </div>
);

export const NaoConformidadesSection = ({ onComplete }: NaoConformidadesSectionProps) => {
  const [activeTab, setActiveTab] = useState<TabType>('pendentes');
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [showActions, setShowActions] = useState(false);
  const [showFullPage, setShowFullPage] = useState(false);

  const naoConformidades = {
    pendentes: [
      { id: 1, doc: 'Descongelamento_Mar_2024.xlsx', item: 'Carne Bovina - Lote 023', desc: 'Temperatura acima do limite (5°C)', date: '22/03/2024', severity: 'high' },
      { id: 2, doc: 'Temperaturas_Abr_2024.xlsx', item: 'Câmara Fria 02', desc: 'Variação de temperatura detectada', date: '15/04/2024', severity: 'medium' },
      { id: 3, doc: 'Estoque_Mai_2024.xlsx', item: 'Frango Congelado - Lote 112', desc: 'Prazo de validade próximo', date: '01/05/2024', severity: 'low' },
    ],
    validadas: [
      { id: 4, doc: 'Recebimento_Jan_2024.xlsx', item: 'Fornecedor ABC', desc: 'Documentação incompleta', date: '10/01/2024', resolvedDate: '12/01/2024' },
      { id: 5, doc: 'Pesagem_Fev_2024.xlsx', item: 'Balança 03', desc: 'Calibração vencida', date: '05/02/2024', resolvedDate: '06/02/2024' },
    ],
    descartadas: [
      { id: 6, doc: 'Descongelamento_Jan_2024.xlsx', item: 'Peixe - Lote 045', desc: 'Falso positivo - sensor defeituoso', date: '08/01/2024', reason: 'Sensor substituído' },
    ],
  };

  useEffect(() => {
    // Sequence: pendentes -> validadas -> descartadas -> actions
    const sequence = async () => {
      await new Promise(r => setTimeout(r, 1000));
      setHighlightIndex(0); // Pendentes tab
      
      await new Promise(r => setTimeout(r, 1500));
      setActiveTab('validadas');
      setHighlightIndex(1);
      
      await new Promise(r => setTimeout(r, 1500));
      setActiveTab('descartadas');
      setHighlightIndex(2);
      
      await new Promise(r => setTimeout(r, 1500));
      setActiveTab('pendentes');
      setHighlightIndex(-1);
      setShowActions(true);
      
      await new Promise(r => setTimeout(r, 3000));
      setShowActions(false);
      setShowFullPage(true);
      
      await new Promise(r => setTimeout(r, 2500));
      onComplete();
    };

    sequence();
  }, [onComplete]);

  const tabs = [
    { id: 'pendentes' as TabType, label: 'Pendentes', count: 3, icon: Clock, color: 'text-warning' },
    { id: 'validadas' as TabType, label: 'Validadas', count: 2, icon: CheckCircle2, color: 'text-success' },
    { id: 'descartadas' as TabType, label: 'Descartadas', count: 1, icon: XCircle, color: 'text-muted-foreground' },
  ];

  return (
    <DashboardLayout activeTab="nao-conformidades">
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-8 h-8 text-destructive" />
            <h1 className="text-3xl font-display font-bold text-foreground">
              Não Conformidades
            </h1>
          </div>
          <p className="text-muted-foreground">
            Gerencie e valide as não conformidades identificadas pela IA
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-4">
          {tabs.map((tab, idx) => (
            <HighlightBox key={tab.id} active={highlightIndex === idx}>
              <motion.button
                className={`flex items-center gap-3 px-6 py-3 rounded-xl font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-secondary text-secondary-foreground shadow-lg'
                    : 'bg-card hover:bg-muted text-muted-foreground'
                }`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + idx * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <tab.icon className={`w-5 h-5 ${tab.color}`} />
                <span>{tab.label}</span>
                <span className={`px-2 py-0.5 rounded-full text-sm ${
                  activeTab === tab.id
                    ? 'bg-white/20'
                    : 'bg-muted'
                }`}>
                  {tab.count}
                </span>
              </motion.button>
            </HighlightBox>
          ))}
        </div>

        {/* Content */}
        <motion.div 
          className={`glass-card rounded-2xl overflow-hidden transition-all duration-500 ${
            showFullPage ? 'ring-2 ring-primary shadow-glow' : ''
          }`}
          animate={showFullPage ? { scale: [1, 1.01, 1] } : {}}
          transition={{ duration: 0.5 }}
        >
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h3 className="font-semibold text-foreground">
              {activeTab === 'pendentes' && 'Não Conformidades Pendentes'}
              {activeTab === 'validadas' && 'Não Conformidades Validadas'}
              {activeTab === 'descartadas' && 'Não Conformidades Descartadas'}
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <FileText className="w-4 h-4" />
              {naoConformidades[activeTab].length} registros
            </div>
          </div>

          <div className="divide-y divide-border">
            <AnimatePresence mode="wait">
              {naoConformidades[activeTab].map((nc, idx) => (
                <motion.div
                  key={nc.id}
                  className="p-4 hover:bg-muted/50 transition-colors"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {'severity' in nc && (
                          <span className={`w-3 h-3 rounded-full ${
                            nc.severity === 'high' ? 'bg-destructive' :
                            nc.severity === 'medium' ? 'bg-warning' : 'bg-muted-foreground'
                          }`} />
                        )}
                        <span className="font-medium text-foreground">{nc.item}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{nc.desc}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <FileText className="w-3 h-3" />
                          {nc.doc}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {nc.date}
                        </span>
                        {'resolvedDate' in nc && (
                          <span className="flex items-center gap-1 text-success">
                            <CheckCircle2 className="w-3 h-3" />
                            Resolvido em {nc.resolvedDate}
                          </span>
                        )}
                        {'reason' in nc && (
                          <span className="text-muted-foreground">
                            Motivo: {nc.reason}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <HighlightBox active={showActions && idx === 0}>
                        <motion.button
                          className="p-2 bg-muted hover:bg-primary/10 rounded-lg transition-colors group"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Eye className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
                        </motion.button>
                      </HighlightBox>

                      {activeTab === 'pendentes' && (
                        <>
                          <HighlightBox active={showActions && idx === 0}>
                            <motion.button
                              className="p-2 bg-success/10 hover:bg-success/20 rounded-lg transition-colors group"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <Check className="w-5 h-5 text-success" />
                            </motion.button>
                          </HighlightBox>

                          <HighlightBox active={showActions && idx === 0}>
                            <motion.button
                              className="p-2 bg-destructive/10 hover:bg-destructive/20 rounded-lg transition-colors group"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <X className="w-5 h-5 text-destructive" />
                            </motion.button>
                          </HighlightBox>
                        </>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Action Labels */}
        <AnimatePresence>
          {showActions && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex justify-center gap-8"
            >
              <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
                <Eye className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Ver Documento</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-success/10 rounded-lg">
                <Check className="w-5 h-5 text-success" />
                <span className="text-sm font-medium text-success">Validar</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-destructive/10 rounded-lg">
                <X className="w-5 h-5 text-destructive" />
                <span className="text-sm font-medium text-destructive">Descartar</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </DashboardLayout>
  );
};
