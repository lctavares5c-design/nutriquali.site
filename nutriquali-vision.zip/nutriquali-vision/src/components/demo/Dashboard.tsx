import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileText, CheckCircle2, AlertTriangle, Clock, Trophy, TrendingUp, ArrowRight, FileSpreadsheet } from 'lucide-react';
import { DashboardLayout } from './DashboardLayout';

interface DashboardProps { onComplete: () => void; }

const AnimatedCounter = ({ target, suffix = '', delay = 0, decimals = 0 }: { target: number; suffix?: string; delay?: number; decimals?: number; }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const startTimer = setTimeout(() => {
      const duration = 2000, steps = 60, increment = target / steps;
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) { setCount(target); clearInterval(timer); }
        else { setCount(decimals > 0 ? parseFloat(current.toFixed(decimals)) : Math.floor(current)); }
      }, duration / steps);
      return () => clearInterval(timer);
    }, delay);
    return () => clearTimeout(startTimer);
  }, [target, delay, decimals]);
  return <span className="font-display font-bold">{decimals > 0 ? count.toFixed(decimals) : count.toLocaleString('pt-BR')}{suffix}</span>;
};

const HighlightBox = ({ children, delay, active }: { children: React.ReactNode; delay: number; active: boolean }) => (
  <motion.div className="relative" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay }}>
    <AnimatePresence>
      {active && <motion.div className="absolute -inset-2 bg-primary/20 rounded-xl border-2 border-primary z-20" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.3 }} />}
    </AnimatePresence>
    <div className="relative z-10">{children}</div>
  </motion.div>
);

export const Dashboard = ({ onComplete }: DashboardProps) => {
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [showSpreadsheetTypes, setShowSpreadsheetTypes] = useState(false);
  const kpis = [
    { icon: FileText, label: 'Documentos Analisados', value: 156, suffix: '', trend: '+12' },
    { icon: CheckCircle2, label: 'Taxa de Conformidade', value: 94.5, suffix: '%', trend: '+2.3%', decimals: 1 },
    { icon: AlertTriangle, label: 'Não Conformidades', value: 23, suffix: '', trend: '-5', trendColor: 'text-destructive' },
    { icon: Clock, label: 'Tempo Médio de Análise', value: 4.2, suffix: 'min', trend: '-1.1min', decimals: 1 },
  ];
  const recentActivity = [
    { unit: 'FPSO Alpha', type: 'Descongelamento', time: '10:30', status: 'nc', ncCount: 2 },
    { unit: 'FPSO Beta', type: 'Cocção e Distribuição', time: '09:15', status: 'ok' },
    { unit: 'Unidade C', type: 'Lanches', time: '08:45', status: 'nc', ncCount: 1 },
  ];
  const ranking = [
    { position: 1, name: 'Carlos Mendes', unit: 'FPSO Alpha', score: 98.5 },
    { position: 2, name: 'Ana Costa', unit: 'FPSO Beta', score: 97.2 },
    { position: 3, name: 'João Santos', unit: 'Unidade C', score: 95.8 },
    { position: 4, name: 'Lucia Ferreira', unit: 'FPSO Gamma', score: 94.1 },
    { position: 5, name: 'Pedro Oliveira', unit: 'Unidade D', score: 93.5 },
  ];

  useEffect(() => {
    const highlights = [0, 1, 2, 3, 4, 5, 6, 7];
    let currentIndex = 0;
    const startHighlights = setTimeout(() => {
      const interval = setInterval(() => {
        if (currentIndex < highlights.length) { setHighlightIndex(highlights[currentIndex]); currentIndex++; }
        else { clearInterval(interval); }
      }, 800);
      return () => clearInterval(interval);
    }, 500);
    return () => clearTimeout(startHighlights);
  }, []);

  useEffect(() => { const timer = setTimeout(() => onComplete(), 6000); return () => clearTimeout(timer); }, [onComplete]);

  return (
    <DashboardLayout activeTab="home">
      <div className="p-5 space-y-5">
        <motion.div className="flex items-center justify-between" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <HighlightBox delay={0.2} active={highlightIndex === 1}>
            <div><h1 className="text-xl font-display font-bold text-foreground">Olá, Maria 👋</h1><p className="text-muted-foreground text-sm">Aqui está o resumo das suas atividades de hoje</p></div>
          </HighlightBox>
          <HighlightBox delay={0.1} active={highlightIndex === 0}>
            <motion.button className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg font-medium text-sm shadow-md" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Upload className="w-4 h-4" />Upload PDF
            </motion.button>
          </HighlightBox>
        </motion.div>

        <div className="grid grid-cols-4 gap-4">
          {kpis.map((kpi, idx) => (
            <HighlightBox key={kpi.label} delay={0.2 + idx * 0.1} active={highlightIndex === 2 + idx}>
              <motion.div className="bg-white rounded-xl p-4 shadow-sm border border-border" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + idx * 0.1 }}>
                <div className="flex items-start justify-between">
                  <div className="p-2 bg-primary/10 rounded-lg"><kpi.icon className="w-5 h-5 text-primary" /></div>
                  <div className={`flex items-center gap-1 text-xs font-medium ${kpi.trendColor || 'text-success'}`}><TrendingUp className="w-3 h-3" />{kpi.trend}</div>
                </div>
                <div className="mt-3"><p className="text-2xl font-display font-bold text-foreground"><AnimatedCounter target={kpi.value} suffix={kpi.suffix} delay={500 + idx * 200} decimals={kpi.decimals || 0} /></p><p className="text-xs text-muted-foreground mt-1">{kpi.label}</p></div>
              </motion.div>
            </HighlightBox>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-5">
          <HighlightBox delay={0.4} active={highlightIndex === 6}>
            <motion.div className="bg-white rounded-xl shadow-sm border border-border h-full" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
              <div className="p-4 border-b border-border flex items-center justify-between"><h3 className="font-semibold text-foreground text-sm">Atividade Recente</h3><button className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1">Ver tudo <ArrowRight className="w-3 h-3" /></button></div>
              <div className="divide-y divide-border">
                {recentActivity.map((item, idx) => (
                  <motion.div key={idx} className="p-4 flex items-center justify-between" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 + idx * 0.1 }}>
                    <div className="flex items-center gap-3">
                      <div className={`w-1.5 h-12 rounded-full ${item.status === 'ok' ? 'bg-success' : 'bg-destructive'}`} />
                      <div className="p-2 bg-muted rounded-lg"><FileSpreadsheet className="w-5 h-5 text-muted-foreground" /></div>
                      <div><p className="font-medium text-foreground text-base">{item.unit}</p><p className="text-sm text-primary">{item.type}</p></div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">{item.time}</span>
                      {item.status === 'ok' ? <span className="px-3 py-1 bg-success/10 text-success text-xs font-medium rounded-full">OK</span> : <span className="px-3 py-1 bg-destructive/10 text-destructive text-xs font-medium rounded-full">{item.ncCount} NC</span>}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </HighlightBox>

          <HighlightBox delay={0.8} active={highlightIndex === 7}>
            <motion.div className="bg-white rounded-xl shadow-sm border border-border h-full" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}>
              <div className="p-4 border-b border-border flex items-center justify-between"><div className="flex items-center gap-2"><Trophy className="w-5 h-5 text-warning" /><h3 className="font-semibold text-foreground text-sm">Ranking</h3></div><div className="flex gap-1"><button className="px-3 py-1 text-xs font-medium bg-muted rounded">Semana</button><button className="px-3 py-1 text-xs text-muted-foreground">Mês</button></div></div>
              <div className="p-4 space-y-4">
                {ranking.map((user, idx) => (
                  <motion.div key={user.name} className="flex items-center justify-between" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1 + idx * 0.1 }}>
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${idx === 0 ? 'bg-warning text-white' : idx === 1 ? 'bg-gray-300 text-gray-700' : idx === 2 ? 'bg-orange-300 text-orange-800' : 'bg-muted text-muted-foreground'}`}>{user.position}</div>
                      <div><p className="font-medium text-foreground text-sm">{user.name}</p><p className="text-xs text-muted-foreground">{user.unit}</p></div>
                    </div>
                    <span className={`font-bold text-sm ${idx === 0 ? 'text-primary' : 'text-foreground'}`}>{user.score}%</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </HighlightBox>
        </div>

        {/* Spreadsheet types section removed as requested */}
      </div>
    </DashboardLayout>
  );
};
