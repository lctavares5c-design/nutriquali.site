import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import logoIA from '@/assets/logo-nutriquali.png'; // Fallback to existing logo if import fails, but I will use the path directly in the img tag for the attached asset

interface LoginScreenProps {
  onComplete: () => void;
}

export const LoginScreen = ({ onComplete }: LoginScreenProps) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isTypingEmail, setIsTypingEmail] = useState(false);
  const [isTypingPassword, setIsTypingPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const targetEmail = 'maria.qualidade@empresa';
  const targetPassword = '••••••••••';

  useEffect(() => {
    // Start typing email after 1.5s
    const startTyping = setTimeout(() => {
      setIsTypingEmail(true);
    }, 1500);

    return () => clearTimeout(startTyping);
  }, []);

  useEffect(() => {
    if (isTypingEmail && email.length < targetEmail.length) {
      const timer = setTimeout(() => {
        setEmail(targetEmail.slice(0, email.length + 1));
      }, 80);
      return () => clearTimeout(timer);
    } else if (email.length === targetEmail.length && !isTypingPassword) {
      const timer = setTimeout(() => {
        setIsTypingPassword(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [email, isTypingEmail, isTypingPassword]);

  useEffect(() => {
    if (isTypingPassword && password.length < targetPassword.length) {
      const timer = setTimeout(() => {
        setPassword(targetPassword.slice(0, password.length + 1));
      }, 100);
      return () => clearTimeout(timer);
    } else if (password.length === targetPassword.length && !isLoggingIn) {
      const timer = setTimeout(() => {
        setIsLoggingIn(true);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [password, isTypingPassword, isLoggingIn]);

  useEffect(() => {
    if (isLoggingIn) {
      const timer = setTimeout(() => {
        onComplete();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isLoggingIn, onComplete]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-accent/20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div 
          className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/10 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div 
          className="absolute -bottom-1/4 -left-1/4 w-1/2 h-1/2 bg-secondary/10 rounded-full blur-3xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity, delay: 4 }}
        />
      </div>

      {/* Floating particles */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary/30 rounded-full"
          style={{
            left: `${20 + i * 15}%`,
            top: `${30 + (i % 3) * 20}%`,
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-10, 10, -10],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 4 + i,
            repeat: Infinity,
            delay: i * 0.5,
          }}
        />
      ))}

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="relative z-10 w-full max-w-md mx-4"
      >
        <div className="glass-card rounded-2xl p-8 shadow-elevated">
          {/* Logo */}
          <motion.div 
            className="flex flex-col items-center mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <img 
              src="/attached_assets/Captura_de_tela_2026-01-12_200623-removebg-preview_1768259431144.png" 
              alt="NutriQuali IA" 
              className="h-24 object-contain mb-4"
            />
            <h2 className="text-3xl font-bold tracking-tight text-[#003366] font-display">NutriQuali IA</h2>
          </motion.div>

          {/* Title */}
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h1 className="text-2xl font-display font-bold text-foreground mb-2">
              Bem-vindo de volta
            </h1>
            <p className="text-muted-foreground text-sm">
              Acesse sua conta para continuar
            </p>
          </motion.div>

          {/* Form */}
          <div className="space-y-5">
            {/* Email Field */}
            <motion.div 
              className="space-y-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
            >
              <label className="text-sm font-medium text-foreground">E-mail</label>
              <div className={`relative rounded-xl border-2 transition-all duration-300 ${
                isTypingEmail ? 'border-primary shadow-glow' : 'border-border'
              }`}>
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  readOnly
                  className="w-full pl-12 pr-4 py-3.5 bg-transparent rounded-xl text-foreground focus:outline-none"
                  placeholder="seu@email.com"
                />
                {isTypingEmail && email.length < targetEmail.length && (
                  <motion.span
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary"
                    animate={{ opacity: [1, 0, 1] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                )}
              </div>
            </motion.div>

            {/* Password Field */}
            <motion.div 
              className="space-y-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
            >
              <label className="text-sm font-medium text-foreground">Senha</label>
              <div className={`relative rounded-xl border-2 transition-all duration-300 ${
                isTypingPassword ? 'border-primary shadow-glow' : 'border-border'
              }`}>
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  readOnly
                  className="w-full pl-12 pr-4 py-3.5 bg-transparent rounded-xl text-foreground focus:outline-none"
                  placeholder="••••••••"
                />
                {isTypingPassword && password.length < targetPassword.length && (
                  <motion.span
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary"
                    animate={{ opacity: [1, 0, 1] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  />
                )}
              </div>
            </motion.div>

            {/* Login Button */}
            <motion.button
              className={`w-full py-4 rounded-xl font-semibold text-primary-foreground flex items-center justify-center gap-2 transition-all duration-300 ${
                isLoggingIn 
                  ? 'bg-primary glow-primary' 
                  : password.length === targetPassword.length
                    ? 'bg-primary hover:bg-primary/90 cursor-pointer'
                    : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              whileTap={password.length === targetPassword.length ? { scale: 0.98 } : {}}
            >
              {isLoggingIn ? (
                <>
                  <motion.div
                    className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  />
                  <span>Entrando...</span>
                </>
              ) : (
                <>
                  <span>Entrar</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </motion.button>
          </div>

          {/* Footer */}
          <motion.p 
            className="text-center text-xs text-muted-foreground mt-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            Protegido por criptografia de ponta a ponta
          </motion.p>
        </div>
      </motion.div>
    </div>
  );
};