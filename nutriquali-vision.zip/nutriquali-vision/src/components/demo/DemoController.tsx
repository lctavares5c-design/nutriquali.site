import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LoginScreen } from './LoginScreen';
import { Dashboard } from './Dashboard';
import { DescongelamentoSection } from './DescongelamentoSection';
import { NaoConformidadesSection } from './NaoConformidadesSection';
import { PerfilSection } from './PerfilSection';
import { FinalScreen } from './FinalScreen';

type DemoStep = 
  | 'login' 
  | 'dashboard' 
  | 'descongelamento' 
  | 'nao-conformidades' 
  | 'perfil' 
  | 'final';

export const DemoController = () => {
  const [currentStep, setCurrentStep] = useState<DemoStep>('login');
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const goToNextStep = useCallback(() => {
    const steps: DemoStep[] = ['login', 'dashboard', 'descongelamento', 'nao-conformidades', 'perfil', 'final'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1]);
    }
  }, [currentStep]);

  const handleStepComplete = useCallback(() => {
    if (isAutoPlaying) {
      goToNextStep();
    }
  }, [isAutoPlaying, goToNextStep]);

  return (
    <div className="min-h-screen w-full overflow-hidden bg-background">
      <AnimatePresence mode="wait">
        {currentStep === 'login' && (
          <motion.div
            key="login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.5 }}
          >
            <LoginScreen onComplete={handleStepComplete} />
          </motion.div>
        )}

        {currentStep === 'dashboard' && (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
          >
            <Dashboard onComplete={handleStepComplete} />
          </motion.div>
        )}

        {currentStep === 'descongelamento' && (
          <motion.div
            key="descongelamento"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
          >
            <DescongelamentoSection onComplete={handleStepComplete} />
          </motion.div>
        )}

        {currentStep === 'nao-conformidades' && (
          <motion.div
            key="nao-conformidades"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
          >
            <NaoConformidadesSection onComplete={handleStepComplete} />
          </motion.div>
        )}

        {currentStep === 'perfil' && (
          <motion.div
            key="perfil"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
          >
            <PerfilSection onComplete={handleStepComplete} />
          </motion.div>
        )}

        {currentStep === 'final' && (
          <motion.div
            key="final"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <FinalScreen />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress Indicator */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <div className="flex gap-2 p-2 bg-secondary/90 backdrop-blur-sm rounded-full">
          {['login', 'dashboard', 'descongelamento', 'nao-conformidades', 'perfil', 'final'].map((step, index) => (
            <button
              key={step}
              onClick={() => setCurrentStep(step as DemoStep)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                currentStep === step 
                  ? 'bg-primary w-8' 
                  : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
