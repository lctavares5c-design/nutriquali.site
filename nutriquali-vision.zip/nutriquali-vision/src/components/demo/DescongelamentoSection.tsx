import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Upload, 
  FileText, 
  AlertTriangle,
  Eye,
  Building,
  ChevronRight,
  Thermometer
} from 'lucide-react';
import { DashboardLayout } from './DashboardLayout';

interface DescongelamentoSectionProps {
  onComplete: () => void;
}

const HighlightBox = ({ children, active, pulse = false }: { children: React.ReactNode; active: boolean; pulse?: boolean }) => (
  <div className="relative">
    <AnimatePresence>
      {active && (
        <motion.div
          className="absolute -inset-2 bg-primary/20 rounded-xl border-2 border-primary z-0"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            boxShadow: pulse ? ['0 0 0 0 rgba(45, 212, 191, 0)', '0 0 20px 10px rgba(45, 212, 191, 0.3)', '0 0 0 0 rgba(45, 212, 191, 0)'] : 'none'
          }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3, boxShadow: { duration: 2, repeat: Infinity } }}
        />
      )}
    </AnimatePresence>
    <div className="relative z-10">{children}</div>
  </div>
);

export const DescongelamentoSection = ({ onComplete }: DescongelamentoSectionProps) => {
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [showUnits, setShowUnits] = useState(false);
  const [expandedUnit, setExpandedUnit] = useState<string | null>(null);

  const documents = [
    { id: 1, name: 'Descongelamento_Jan_2024.xlsx', date: '15/01/2024', status: 'analyzed', ncs: 2 },
    { id: 2, name: 'Descongelamento_Fev_2024.xlsx', date: '18/02/2024', status: 'analyzed', ncs: 0 },
    { id: 3, name: 'Descongelamento_Mar_2024.xlsx', date: '22/03/2024', status: 'pending', ncs: 5 },
    { id: 4, name: 'Descongelamento_Abr_2024.xlsx', date: '10/04/2024', status: 'analyzed', ncs: 1 },
  ];

  const units = {
    'FPSO Alpha': [
      { name: 'Carne Bovina - Lote 001', temp: '-2°C', status: 'conforme' },
      { name: 'Frango Congelado - Lote 045', temp: '3°C', status: 'nc' },
      { name: 'Peixe Congelado - Lote 112', temp: '-1°C', status: 'conforme' },
    ],
    'FPSO Beta': [
      { name: 'Camarão Congelado - Lote 078', temp: '0°C', status: 'conforme' },
      { name: 'Carne Suína - Lote 023', temp: '-3°C', status: 'conforme' },
      { name: 'Legumes Congelados - Lote 089', temp: '5°C', status: 'nc' },
    ],
  };

  useEffect(() => {
    // Sequence through highlights
    const sequence = [0, 1, 2, 3];
    let currentIndex = 0;

    const startHighlights = setTimeout(() => {
      const interval = setInterval(() => {
        if (currentIndex < sequence.length) {
          setHighlightIndex(sequence[currentIndex]);
          currentIndex++;
        } else {
          clearInterval(interval);
          setShowUnits(true);
        }
      }, 1200);

      return () => clearInterval(interval);
    }, 500);

    return () => clearTimeout(startHighlights);
  }, []);

  useEffect(() => {
    if (showUnits) {
      // Animate through units
      const timer1 = setTimeout(() => {
        setExpandedUnit('FPSO Alpha');
      }, 1000);

      const timer2 = setTimeout(() => {
        setExpandedUnit('FPSO Beta');
      }, 3000);

      const timer3 = setTimeout(() => {
        onComplete();
      }, 5000);

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
        clearTimeout(timer3);
      };
    }
  }, [showUnits, onComplete]);

  return (
    <DashboardLayout activeTab="descongelamento">
      <div className="p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-2">
            <Thermometer className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-display font-bold text-foreground">
              Descongelamento
            </h1>
          </div>
          <p className="text-muted-foreground">
            Gerencie e analise planilhas de controle de descongelamento
          </p>
        </motion.div>

        {/* Upload Section */}
        <HighlightBox active={highlightIndex === 0} pulse>
          <motion.div 
            className="glass-card rounded-2xl p-8 border-2 border-dashed border-primary/30 hover:border-primary/50 transition-colors cursor-pointer"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                <Upload className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Upload de Planilhas
              </h3>
              <p className="text-muted-foreground max-w-md">
                Arraste suas planilhas de descongelamento aqui ou clique para selecionar arquivos
              </p>
              <div className="mt-4 flex gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">.xlsx</span>
                <span className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">.xls</span>
                <span className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">.csv</span>
              </div>
            </div>
          </motion.div>
        </HighlightBox>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <HighlightBox active={highlightIndex === 1}>
            <motion.div 
              className="glass-card rounded-xl p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-xl">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Documentos</p>
                  <p className="text-3xl font-display font-bold text-foreground">456</p>
                </div>
              </div>
            </motion.div>
          </HighlightBox>

          <HighlightBox active={highlightIndex === 2}>
            <motion.div 
              className="glass-card rounded-xl p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-destructive/10 rounded-xl">
                  <AlertTriangle className="w-6 h-6 text-destructive" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Não Conformidades</p>
                  <p className="text-3xl font-display font-bold text-destructive">23</p>
                </div>
              </div>
            </motion.div>
          </HighlightBox>

          <HighlightBox active={highlightIndex === 3}>
            <motion.div 
              className="glass-card rounded-xl p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-success/10 rounded-xl">
                  <Eye className="w-6 h-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ver PDF</p>
                  <button className="text-primary font-semibold hover:underline">
                    Visualizar Relatório →
                  </button>
                </div>
              </div>
            </motion.div>
          </HighlightBox>
        </div>

        {/* Documents Table */}
        <motion.div 
          className="glass-card rounded-2xl overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-foreground">Documentos Recentes</h3>
          </div>
          <div className="divide-y divide-border">
            {documents.map((doc, idx) => (
              <motion.div 
                key={doc.id}
                className="p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + idx * 0.1 }}
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-muted rounded-lg">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{doc.name}</p>
                    <p className="text-sm text-muted-foreground">{doc.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {doc.ncs > 0 && (
                    <span className="px-2 py-1 bg-destructive/10 text-destructive text-sm rounded-full">
                      {doc.ncs} NCs
                    </span>
                  )}
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    doc.status === 'analyzed' 
                      ? 'bg-success/10 text-success' 
                      : 'bg-warning/10 text-warning'
                  }`}>
                    {doc.status === 'analyzed' ? 'Analisado' : 'Pendente'}
                  </span>
                  <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                    <Eye className="w-5 h-5 text-muted-foreground" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Units Section */}
        <AnimatePresence>
          {showUnits && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-display font-semibold text-foreground flex items-center gap-2">
                <Building className="w-6 h-6 text-primary" />
                Unidades
              </h3>

              {Object.entries(units).map(([unitName, items]) => (
                <motion.div
                  key={unitName}
                  className={`glass-card rounded-xl overflow-hidden ${
                    expandedUnit === unitName ? 'ring-2 ring-primary shadow-glow' : ''
                  }`}
                  animate={expandedUnit === unitName ? { scale: [1, 1.01, 1] } : {}}
                  transition={{ duration: 0.3 }}
                >
                  <div 
                    className="p-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Building className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{unitName}</p>
                        <p className="text-sm text-muted-foreground">{items.length} itens</p>
                      </div>
                    </div>
                    <ChevronRight className={`w-5 h-5 text-muted-foreground transition-transform ${
                      expandedUnit === unitName ? 'rotate-90' : ''
                    }`} />
                  </div>

                  <AnimatePresence>
                    {expandedUnit === unitName && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="border-t border-border"
                      >
                        <div className="p-4 space-y-3">
                          {items.map((item, idx) => (
                            <motion.div
                              key={idx}
                              className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: idx * 0.1 }}
                            >
                              <div className="flex items-center gap-3">
                                <Thermometer className={`w-5 h-5 ${
                                  item.status === 'conforme' ? 'text-success' : 'text-destructive'
                                }`} />
                                <span className="text-foreground">{item.name}</span>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className="font-mono text-sm text-muted-foreground">{item.temp}</span>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  item.status === 'conforme' 
                                    ? 'bg-success/10 text-success' 
                                    : 'bg-destructive/10 text-destructive'
                                }`}>
                                  {item.status === 'conforme' ? 'Conforme' : 'NC'}
                                </span>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </DashboardLayout>
  );
};
