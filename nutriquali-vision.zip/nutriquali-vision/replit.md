# NutriQuali IA

## Overview
NutriQuali IA is a React-based web application built with Vite, TypeScript, and Tailwind CSS. It appears to be a food quality management system with features for login, dashboard, and compliance tracking.

## Project Architecture

### Tech Stack
- **Frontend**: React 18 with TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS with shadcn/ui components
- **Routing**: React Router DOM v6
- **State Management**: TanStack React Query
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion

### Directory Structure
```
src/
├── assets/          # Static assets (logo)
├── components/
│   ├── demo/        # Demo/feature components (Dashboard, Login, etc.)
│   └── ui/          # shadcn/ui components
├── hooks/           # Custom React hooks
├── lib/             # Utility functions
├── pages/           # Page components (Index, NotFound)
├── App.tsx          # Main app component
├── main.tsx         # App entry point
└── index.css        # Global styles
```

### Key Files
- `vite.config.ts` - Vite configuration (port 5000, all hosts allowed)
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration

## Development

### Running the App
The application runs on port 5000 with the command:
```bash
npm run dev
```

### Building for Production
```bash
npm run build
```
Output is in the `dist/` directory for static deployment.

## Recent Changes
- Migrated from Lovable to Replit environment
- Updated Vite config to use port 5000 with `allowedHosts: true`
- Removed lovable-tagger plugin dependency from Vite config

## User Preferences
(To be updated based on user feedback)
